//
//  HomeView.swift
//  PawTrails
//
//  Created by Sheren Emanuela on 21/05/23.
//

import SwiftUI
import CoreLocation
import MapKit

struct HomeView: View {
    
    @EnvironmentObject var locationManager: LocationManager
    @State var navigateToResult: Bool = false
    @State var target: String = ""
    @State var overlayOpacity: Double = 0
    @State var targetPromptPosY: Double = -400
    @State var reportOpacity: Double = 0
    @State var targetInKm: Double = 0
    @State var popupPadding: Double  = 0
    @State var width: Double = 0
    @State var height: Double = 0
    @State var resultOffset: CGSize = CGSize(width: 0, height: 400)
    @StateObject var timeKeeper: TimeKeeper = TimeKeeper()
    
    var route: MKPolyline?
    
    var body: some View {
        NavigationStack {
            ZStack {
                
                Group {
                    MapView()
                        .environmentObject(locationManager)
                        
                    
                    Button {
                        overlayOpacity = 0.5
                        width = .infinity
                        height = .infinity
                        
                        withAnimation(.linear(duration: 0.5)) {
                            targetPromptPosY = 0
                        }
                    } label: {
                        ButtonView(text: "START TRACKING", width: 340)
                    }
                    .frame(maxHeight: .infinity, alignment: .bottom)
                    .padding(.bottom, 30)
                    
                    Color("Beige")
                        .opacity(overlayOpacity)
                        .frame(width: width, height: height)
                        .onTapGesture {
                            overlayOpacity = 0
                            width = 0
                            height = 0
                            
                            withAnimation(.linear(duration: 0.5)) {
                                targetPromptPosY = -400
                            }
                        }
                }
                
                ZStack {
                    Group {
                        Rectangle()
                            .frame(width: 390, height: 260)
                            .cornerRadius(30)
                            .frame(maxHeight: .infinity, alignment: .top)
                            .shadow(radius: 10)
                            .foregroundColor(.white)
                        
                        VStack (alignment: .leading){
                            Text("Daily Target")
                                .font(.system(size: 25, weight: .heavy, design: .rounded))
                                .padding(.horizontal, 30)
                                .padding(.bottom, 10)
                            
                            ZStack {
                                TextField("", text: $target)
                                    .font(.system(size: 20, weight: .heavy, design: .rounded))
                                    .frame(width: 300, height: 20)
                                    .padding()
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 50)
                                            .stroke(Color("Brown"), lineWidth: 3)
                                    )
                                
                                Text("KM")
                                    .font(.system(size: 20, weight: .heavy, design: .rounded))
                                    .frame(maxWidth: .infinity, alignment: .trailing)
                                    .padding(.trailing, 50)
                            }
                            .padding(.bottom, 10)
                            
                            Button {
                                if !target.isEmpty && Double(target) != nil {
                                    if Double(target)! > 0 {
                                        targetInKm = Double(target)!
                                        overlayOpacity = 0
                                        withAnimation(.linear(duration: 0.5)) {
                                            targetPromptPosY = -400
                                        }
                                        target = ""
                                        locationManager.startTracking()
                                        timeKeeper.startTimer()
                                        reportOpacity = 1
                                        width = 0
                                        height = 0
                                        
                                        withAnimation(.linear(duration: 0.5)) {
                                            targetPromptPosY = -400
                                            resultOffset = CGSizeZero
                                        }
                                    }
                                }
                            } label: {
                                ButtonView(text: "START", width: 120)
                            }
                            .frame(maxWidth: .infinity, alignment: .trailing)
                            .padding(.trailing, 30)
                        }
                        .frame(maxHeight: .infinity, alignment: .top)
                        .padding(.top, 70)
                    }
                    .offset(CGSize(width: 0, height: targetPromptPosY))
                }
                .foregroundColor(Color("Brown"))
                
                ZStack {
                    Rectangle()
                        .frame(width: 390, height: 220)
                        .cornerRadius(30)
                        .frame(maxHeight: .infinity, alignment: .bottom)
                        .shadow(radius: 10)
                        .foregroundColor(.white)
                    
                    VStack {
                        HStack {
                            VStack {
                                Text("\(timeKeeper.formatTime(timeKeeper.counter))")
                                    .font(.system(size: 30, weight: .heavy, design: .rounded))
                                    .padding(.horizontal, 30)
                                    .padding(.bottom, 1)
                                
                                Text("Duration")
                                    .font(.system(size: 20, weight: .regular, design: .rounded))
                                    .padding(.horizontal, 30)
                            }
                            .padding(.trailing, 20)
                            
                            
                            VStack {
                                Text("\(locationManager.distance, specifier: "%.2f")")
                                    .font(.system(size: 30, weight: .heavy, design: .rounded))
                                    .padding(.horizontal, 30)
                                    .padding(.bottom, 1)
                                
                                Text("Distance(KM)")
                                    .font(.system(size: 20, weight: .regular, design: .rounded))
                                    .padding(.horizontal, 30)
                            }
                        }
                        .padding(.bottom, 20)
                        
                        if locationManager.isTracking {
                            Button {
                                locationManager.stopTracking()
                                timeKeeper.stopTimer()
                            } label: {
                                ButtonView(text: "DONE", width: 340)
                            }
                            .padding(.bottom, 40)
                        } else {
                            Button {
                                navigateToResult = true
                            } label: {
                                ButtonView(text: "NEXT", width: 340)
                            }
                            .padding(.bottom, 40)
                        }
                    }
                    .frame(maxHeight: .infinity, alignment: .bottom)
                }
                .frame(maxHeight: .infinity, alignment: .bottom)
                .opacity(reportOpacity)
                .offset(resultOffset)
                .foregroundColor(Color("Brown"))
            }
            .navigationBarBackButtonHidden(true)
            .navigationDestination(isPresented: $navigateToResult) {
                if locationManager.distance >= targetInKm {
                    ResultView(mainText: "Congratulations", image: "Happy", targetText: "Reached", target: targetInKm, distance: locationManager.distance, textColor: Color("Green"))
                } else {
                    ResultView(mainText: "That's Too Bad", image: "Sad", targetText: "Not Reached", target: targetInKm, distance: locationManager.distance, textColor: Color("Red"))
                }
            }
        }
        .ignoresSafeArea()
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
            .environmentObject(LocationManager())
    }
}
