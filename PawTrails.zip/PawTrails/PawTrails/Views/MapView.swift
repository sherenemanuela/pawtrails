//
//  MapView.swift
//  PawTrails
//
//  Created by Sheren Emanuela on 21/05/23.
//

import SwiftUI
import MapKit
import CoreLocation

struct MapView: UIViewRepresentable {
    @EnvironmentObject var locationManager: LocationManager
    
    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView()
        mapView.showsUserLocation = true
        mapView.delegate = context.coordinator
        return mapView
    }
    
    func updateUIView(_ uiView: MKMapView, context: Context) {
        if let location = locationManager.location?.coordinate {
            let region = MKCoordinateRegion(center: location, latitudinalMeters: 500, longitudinalMeters: 500)
            uiView.setRegion(region, animated: true)
        }
        
        uiView.removeOverlays(uiView.overlays)

        if !locationManager.routeCoordinates.isEmpty {
            let polyline = MKPolyline(coordinates: locationManager.routeCoordinates, count: locationManager.routeCoordinates.count)
            uiView.addOverlay(polyline)
            let region = MKCoordinateRegion(polyline.boundingMapRect)
        }
        
    }
    
    func makeCoordinator() -> MapCoordinator {
        MapCoordinator()
    }
    
    class MapCoordinator: NSObject, MKMapViewDelegate {
        func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
            
            if annotation is MKUserLocation {
                return nil
            }
            return MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: "pin")
        }
        
        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            let renderer = MKPolylineRenderer(polyline: overlay as! MKPolyline)
            renderer.strokeColor = .systemBrown
            renderer.lineWidth = 5
            renderer.alpha = 1
            return renderer
        }
    }
}
