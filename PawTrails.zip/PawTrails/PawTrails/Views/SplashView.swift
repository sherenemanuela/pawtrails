//
//  SplashView.swift
//  PawTrails
//
//  Created by Sheren Emanuela on 21/05/23.
//

import SwiftUI

struct SplashView: View {
    
    @State var navigateToHomeView = false
//    @EnvironmentObject var locationManager: LocationManager
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color("Beige")
                
                VStack {
                    Image("SplashLogo")
                    Text("PawTrails")
                        .font(.custom(
                            "Vanilla Caramel",
                            size: 48))
                        .foregroundColor(Color("Brown"))
                }
            }
            .ignoresSafeArea()
            .onAppear() {
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 3) {
                    navigateToHomeView = true
                }
            }
            .navigationDestination(isPresented: $navigateToHomeView) {
                HomeView()
                    .environmentObject(LocationManager())
            }
        }
    }
}

struct SplashView_Previews: PreviewProvider {
    static var previews: some View {
        SplashView()
    }
}
