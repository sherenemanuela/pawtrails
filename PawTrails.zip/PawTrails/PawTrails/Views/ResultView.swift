//
//  ResultView.swift
//  PawTrails
//
//  Created by Sheren Emanuela on 23/05/23.
//

import SwiftUI

struct ResultView: View {
    
    let mainText: String
    let image: String
    let targetText: String
    let target: Double
    let distance: Double
    let textColor: Color
    @State var opacity: Double = 0
    @State var buttonOpacity: Double = 0
    @State var navigateToHome: Bool = false
    
    var body: some View {
        
        ZStack {
            Color("Beige")
                .ignoresSafeArea()
            
                VStack {
                    Group {
                        Text("\(mainText)")
                            .font(.system(size: 35, weight: .heavy, design: .rounded))
                        
                        Image("\(image)")
                            .resizable()
                            .frame(width: 280, height: 280)
                        
                        Text("Target \(targetText)")
                            .font(.system(size: 30, weight: .bold, design: .rounded))
                            .padding(.bottom, 1)
                            .padding(.top, 20)
                        
                        Text("\(distance, specifier: "%.2f") / \(target, specifier: "%.2f") KM")
                            .font(.system(size: 25, weight: .heavy, design: .rounded))
                            .foregroundColor(textColor)
                    }
                    .opacity(opacity)
                    
                    Button {
                        navigateToHome = true
                    } label: {
                        ButtonView(text: "BACK TO HOME", width: 280)
                    }
                    .opacity(buttonOpacity)
                    .padding()
                
            }
            .navigationDestination(isPresented: $navigateToHome) {
                HomeView()
                    .environmentObject(LocationManager())
            }
        }
        .foregroundColor(Color("Brown"))
        .navigationBarBackButtonHidden(true)
        .onAppear() {
            withAnimation(.linear(duration: 1)) {
                opacity = 1
            }
            
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1) {
                withAnimation(.linear(duration: 0.5)) {
                    buttonOpacity = 1
                }
            }
        }
    }
}

struct ResultView_Previews: PreviewProvider {
    static var previews: some View {
        ResultView(mainText: "Congratulations", image: "Happy", targetText: "Reached", target: 2.5, distance: 2.5, textColor: Color("Green"))
    }
}
