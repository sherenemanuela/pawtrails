//
//  ButtonView.swift
//  PawTrails
//
//  Created by Sheren Emanuela on 22/05/23.
//

import SwiftUI

struct ButtonView: View {
    
    let text: String
    let width: Double
    
    var body: some View {
        
        ZStack {
            Color("Brown")
                .frame(width: width, height: 45)
                .cornerRadius(30)
                .shadow(radius: 5)
            
            Text("\(text)")
                .font(.system(size: 20, weight: .heavy, design: .rounded))
                .foregroundColor(.white)
        }
    }
}

struct ButtonView_Previews: PreviewProvider {
    static var previews: some View {
        ButtonView(text: "START TRACKING", width: 500)
    }
}
