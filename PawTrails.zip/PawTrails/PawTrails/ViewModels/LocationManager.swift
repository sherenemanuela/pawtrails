//
//  LocationManager.swift
//  PawTrails
//
//  Created by Sheren Emanuela on 21/05/23.
//

import SwiftUI
import CoreLocation
import MapKit

@MainActor
class LocationManager: NSObject, ObservableObject {
    @Published var location: CLLocation?
    @Published var region = MKCoordinateRegion()
    @Published var distance: Double = 0
    
    var routeCoordinates: [CLLocationCoordinate2D] = []
    private let locationManager = CLLocationManager()
    var locationsPassed = [CLLocation]()
    var isTracking: Bool = false
    
    override init() {
        super.init()
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = kCLDistanceFilterNone
        locationManager.requestAlwaysAuthorization()
        locationManager.startUpdatingLocation()

        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1) {
            self.locationManager.stopUpdatingLocation()
        }
        locationManager.delegate = self
    }
    
    func startTracking() {
        isTracking = true
        locationManager.startUpdatingLocation()
    }
    
    func stopTracking() {
        locationManager.stopUpdatingLocation()
        isTracking = false
    }
    
    func addLocationsToArray(_ locations: [CLLocation]) {
        for location in locations {
            if !locationsPassed.contains(location) {
                locationsPassed.append(location)
                routeCoordinates.append(location.coordinate)
            }
        }
    }
    
    func calculateAndDisplayDistance() {
        var totalDistance = 0.0
        for i in 1 ..< locationsPassed.count {
            let previousLocation = locationsPassed[i-1]
            let currentLocation = locationsPassed[i]
            totalDistance += currentLocation.distance(from: previousLocation)
        }
        distance = totalDistance / 1000
    }
}

extension LocationManager: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
        self.location = location
        
        if isTracking {
            addLocationsToArray(locations)
            calculateAndDisplayDistance()
        }
        
        self.region = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: 500, longitudinalMeters: 500)
    }
}
