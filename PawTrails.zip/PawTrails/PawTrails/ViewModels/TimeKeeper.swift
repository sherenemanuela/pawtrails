//
//  TimeKeeper.swift
//  PawTrails
//
//  Created by Sheren Emanuela on 22/05/23.
//

import Foundation

class TimeKeeper: ObservableObject {
    
    @Published var counter = 0
    @Published var timer: Timer?
    
    func startTimer() {
        guard timer == nil else { return }
        
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            self.counter += 1
        }
    }

    func stopTimer() {
        timer?.invalidate()
        timer = nil
    }

    func formatTime(_ time: Int) -> String {
        let formatter = DateComponentsFormatter()
        formatter.allowedUnits = [.minute, .second]
        formatter.zeroFormattingBehavior = .pad
        return formatter.string(from: TimeInterval(time)) ?? ""
    }
}
