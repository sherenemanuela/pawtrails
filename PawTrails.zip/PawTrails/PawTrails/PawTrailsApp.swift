//
//  PawTrailsApp.swift
//  PawTrails
//
//  Created by Sheren Emanuela on 21/05/23.
//

import SwiftUI

@main
struct PawTrailsApp: App {
    
    @StateObject var locationManager = LocationManager()
    
    var body: some Scene {
        WindowGroup {
            SplashView()
                .environmentObject(locationManager)
        }
    }
}
